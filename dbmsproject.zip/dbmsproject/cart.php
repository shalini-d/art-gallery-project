<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="art-gallery" content="project">
    <meta name="shalini" content="cse">
    <link rel="icon" href="../../favicon.ico">

    <title>Starter Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/starter-template.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>
    <link rel="stylesheet" href="css/demo.css">

	  <link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	  <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/custom.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">ART Gallery</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.html">Home</a></li>

            <li><a href="#" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Exhibition <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                  <li><a href="art.html">Painting</a></li>
                  <li><a href="Sculpture.html">Sculpture</a></li>

              </ul>
            </li>
            <li><a href="insertDetails.html">Insert</a></li>
            <li><a href="deleteDetails.html">Delete</a></li>
            <li><a href="contact.html">Contact Us</a></li>
                <li><a href="sign.html">Login</a></li>
                <li><a href="sale.php">Sale</a></li>
                  <li><a href="cart.php">Cart</a></li>
          </ul>
          <div class="right-navi">
            <button type="button" class="btn btn-default btn-xsm shalu-search"><span class="glyphicon glyphicon-search" aria-hidden="true"><a href="searchDetails.html"> Search   </a></span></button>
          </div>
        </div><!--/.nav-collapse -->

      </div>
    </nav>

<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "mydb1");
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title> Online Shopping Cart </title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<body>
<div class="container" style="width:60%;">
<h2 style="text-align: center;color: blue;text-decoration: underline;"> Online Shopping Cart </h2>
  <?php
$query = "SELECT * FROM products ORDER BY id ASC";
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
  while($row = mysqli_fetch_array($result))
  {
    ?>
          <div class="col-md-3">
          <form method="post" action="shop.php?action=add&id=<?php echo $row["id"]; ?>">
          <div style="border: 1px solid #eaeaec; margin: -1px 19px 3px -1px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); padding:10px;" align="center">
          <img src="<?php echo $row["image"]; ?>" class="img-responsive">
          <h5 class="text-info"><?php echo $row["p_name"]; ?></h5>
          <h5 class="text-danger">Rs <?php echo $row["price"]; ?></h5>
          <input type="text" name="quantity" class="form-control" value="1">
          <input type="hidden" name="hidden_name" value="<?php echo $row["p_name"]; ?>">
          <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
          <input type="submit" name="add" style="margin-top:5px;background-color: #b2b2b2;" class="btn btn-default" value="Add to cart">
          </div>
          </form>
          </div>
          <?php
  }
}
?>
  <div style="clear:both"></div>
  <h2 style="color:red;">My Shopping Bag</h2>
  <div class="table-responsive">

    <table class>
        <style>
    table, th, td {


        border: 2px solid black;
        background-color: white;
        font-size: 16px;
        padding:5px;
        margin-left: 0.1cm;
        margin-top:0.1cm;
        background-origin: 'padding-box';
        text-align: 'center';
        font-family: 'italic';


    }
    h1{
      font-size: 40px;
      font-style: 'italic';
    }
    </style>

  <table class >
  <tr>
  <th width="40%">Product Name</th>
  <th width="10%">Quantity</th>
  <th width="20%">Price Details</th>
  <th width="15%">Order Total</th>
  <th width="5%">Action</th>
  </tr>
  <?php
if(!empty($_SESSION["cart"]))
{
  $total = 0;
  foreach($_SESSION["cart"] as $keys => $values)
  {
    ?>
          <tr>
          <td><?php echo $values["item_name"]; ?></td>
          <td><?php echo $values["item_quantity"] ?></td>
          <td>Rs <?php echo $values["product_price"]; ?></td>
          <td>Rs <?php echo number_format($values["item_quantity"] * $values["product_price"], 2); ?></td>
          <td><a href="shop.php?action=delete&id=<?php echo $values["product_id"]; ?>"><span class="text-danger">X</span></a></td>
          </tr>
          <?php
    $total = $total + ($values["item_quantity"] * $values["product_price"]);
  }
  ?>
      <tr>
      <td colspan="3" align="right">Total</td>
      <td align="right">Rs <?php echo number_format($total, 2); ?></td>
      <td></td>
      </tr>
      <?php
}
?>
  </table>
  </div>
  </div>
</body>
</html>



    <footer class="footer-distributed">

			<div class="footer-left">

				<h3>ART<span>MUSEUM</span></h3>

				<p class="footer-links">
					<a href="#">Home</a>
					·
					<a href="#">Blog</a>
					·
					<a href="#">Pricing</a>
					·
					<a href="#">About</a>
					·
					<a href="#">Faq</a>
					·
					<a href="#">Contact</a>
				</p>

				<p class="footer-company-name">art gallery &copy; 2017</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>21 Revolution Street</span> banglore, India</p>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+91 557 123456</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">artgallery@company.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About the company</span>
			This is the dbms project of art gallery
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-github"></i></a>

				</div>

			</div>

		</footer>




    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
