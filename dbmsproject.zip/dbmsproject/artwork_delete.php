<?php
$servername="localhost";
$username="root";
$password="";

$conn=new mysqli($servername,$username,$password,'mydb1');

if($conn->connect_error) {
  die("Connection error:".$conn->connect_error);
}
echo "Connected successfully";

$a_title = $_POST['title'];
$a_year = $_POST['year'];

$sql = "DELETE FROM artwork_details WHERE title = '$a_title'";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:index.html");
$conn->close();
?>
