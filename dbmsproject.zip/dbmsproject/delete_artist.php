<?php
$servername="localhost";
$username="root";
$password="";

$conn=new mysqli($servername,$username,$password,'mydb1');

if($conn->connect_error) {
  die("Connection error:".$conn->connect_error);
}
echo "Connected successfully";

$a_id = $_POST['artist_id'];

$sql = "DELETE FROM artist_details WHERE artist_id='$a_id'";


if ($conn->query($sql) === TRUE) {
    echo "Item DELETED Successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:deleteDetails.html");
$conn->close();
?>
