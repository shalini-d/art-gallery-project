<?php
$servername = "localhost";
$username = "root";
$password = '';

// Create connection
$conn = new mysqli($servername, $username, $password, 'mydb1');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$f_name = $_POST['fname'];
$l_name = $_POST['lname'];
$a_email = $_POST['aemail'];
$a_message = $_POST['amessage'];
$a_website = $_POST['awebsite'];

$sql = "INSERT INTO contact  (fname, lname, amessage, awebsite, aemail)
VALUES ('$fname','$l_name','$a_message','$a_website','$a_email')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:index.html");
$conn->close();
?>
